﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public struct LightPos
{
    public Vector2 position;
    public float zRot;
}

public class GuardLight : MonoBehaviour
{
    public LightPos upPos;
    public LightPos downPos;
    public LightPos leftPos;
    public LightPos rightPos;
    public GuardMovement movement;

    void LateUpdate()
    {
        switch (movement.walk)
        {
            case -1:
                Apply(downPos);
                break;
            case 0:
                Apply(upPos);
                break;
            case 1:
                Apply(downPos);
                break;
            case 2:
                Apply(leftPos);
                break;
            case 3:
                Apply(rightPos);
                break;
        }
    }

    public void Apply(LightPos pos)
    {
        transform.localPosition = pos.position;
        transform.localRotation = Quaternion.Euler(0, 0, pos.zRot);
    }
}

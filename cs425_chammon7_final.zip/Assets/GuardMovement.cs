﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GuardMovement : MonoBehaviour
{
    public Color debugPathColor = Color.white;
    public Vector2[] pathing;
    private int pathNode = 0;
    private int pathDirection = 1;
    public float movementSpeed = 0.005f;
    private Animator anim;
    public GuardLight myLight;
    public PathPlanning pather;
    public bool playerSpotted = false;
    public int walk { get; private set; } = -1;
    private LineRenderer lr;
    private GameObject player;

    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player");
        lr = gameObject.AddComponent<LineRenderer>();
        lr.startWidth = 0.1f;
        lr.endWidth = 0.1f;
        this.transform.localPosition = pathing[0];
        anim = GetComponent<Animator>();
        Ctrl.onPlayerSpotted += Ctrl_onPlayerSpotted;
        Ctrl.onPlayerCaught += Ctrl_onPlayerCaught;
    }

    private void OnDestroy()
    {
        Ctrl.onPlayerSpotted -= Ctrl_onPlayerSpotted;
        Ctrl.onPlayerCaught -= Ctrl_onPlayerCaught;
    }

    private void Ctrl_onPlayerSpotted(Ctrl player, GameObject spotter)
    {
        if (spotter != myLight.gameObject)
        {
            return;
        }
        playerSpotted = true;
        Debug.LogError("I, " + gameObject.name + ", have spotted the player");
    }
    private void Ctrl_onPlayerCaught(Ctrl player, GameObject spotter)
    {
        if (spotter != gameObject)
        {
            return;
        }
        anim.SetInteger("direction", -1);
        PathPlanning.freezeThese.Add(GetComponent<Rigidbody2D>());
        this.enabled = false;
        myLight.gameObject.SetActive(false);
    }

    private void Update()
    {
        Vector2 currentPos = new Vector2(this.transform.localPosition.x, this.transform.localPosition.y);
        Vector2 next = Vector2.zero;

        float speed = movementSpeed;

        if (playerSpotted)
        {
            List<Vector2> path;
            pather.find_path(new Vector2(transform.position.x, transform.position.y), new Vector2(player.transform.position.x, player.transform.position.y), out path);
            lr.positionCount = path.Count;
            for (int i = 0; i < path.Count; i++)
            {
                lr.SetPosition(i, path[i]);
            }
            if (path.Count == 0)
            {
                playerSpotted = false;
                return;
            }
            speed = movementSpeed * 2f;
            next = path[0];
        }
        else
        {
            next = pathing[pathNode + pathDirection];
        }
        Vector2 dir = next - currentPos;
        float distance = dir.magnitude;
        dir = dir.normalized;
        Vector2 projectedPosition = currentPos + dir * speed;
        if ((projectedPosition - currentPos).magnitude > distance || projectedPosition == next)
        {
            projectedPosition = next;
            pathNode += pathDirection;
            if (pathNode == pathing.Length - 1 || pathNode == 0)
            {
                pathDirection *= -1;
            }
        }

        float up = Vector2.Dot(Vector2.up, dir);
        float down = Vector2.Dot(Vector2.down, dir);
        float left = Vector2.Dot(Vector2.left, dir);
        float right = Vector2.Dot(Vector2.right, dir);
        //Debug.Log(up + " " + down + " " + left + " " + right);

        walk = -1;
        float max = 0;

        if (up > max)
        {
            max = up;
            walk = 0;
        }
        if (down > max)
        {
            max = down;
            walk = 1;
        }
        if (left > max)
        {
            max = left;
            walk = 2;
        }
        if (right > max)
        {
            max = right;
            walk = 3;
        }

        anim.SetInteger("direction", walk);


        this.transform.localPosition = projectedPosition;
    }

}

﻿using UnityEngine;
using System.Collections;

public class Ctrl : MonoBehaviour
{
    public delegate void OnPlayerSpottedEventHandler(Ctrl player, GameObject spotter);
    public static event OnPlayerSpottedEventHandler onPlayerSpotted;
    public static event OnPlayerSpottedEventHandler onPlayerCaught;

    Animator m_Animator;
    public float speed;                //Floating point variable to store the player's movement speed.
    public int direction; //float to store player's direction

    private Rigidbody2D rb2d;        //Store a reference to the Rigidbody2D component required to use 2D Physics.
    void Start()
    {
        //Get and store a reference to the Rigidbody2D component so that we can access it.

        rb2d = GetComponent<Rigidbody2D>();
        m_Animator = GetComponent<Animator>();

    }

    //FixedUpdate is called at a fixed interval and is independent of frame rate. Put physics code here.
    void Update()
    {
        //Store the current horizontal input in the float moveHorizontal.
        float moveHorizontal = Input.GetAxis("Horizontal");

        //Store the current vertical input in the float moveVertical.
        float moveVertical = Input.GetAxis("Vertical");

        //Use the two store floats to create a new Vector2 variable movement.
        Vector2 movement = new Vector2(moveHorizontal, moveVertical);


        //Call the AddForce function of our Rigidbody2D rb2d supplying movement multiplied by speed to move our player.
        //rb2d.AddForce(movement * speed);

        if (Input.GetKeyDown(KeyCode.W))
        {
            m_Animator.SetInteger("direction", 0);
        }
        if (Input.GetKeyDown(KeyCode.S))
        {
            m_Animator.SetInteger("direction", 1);
        }
        if (Input.GetKeyDown(KeyCode.A))
        {
            m_Animator.SetInteger("direction", 2);
        }
        if (Input.GetKeyDown(KeyCode.D))
        {
            m_Animator.SetInteger("direction", 3);
        }
        else
        {
            //do nothing
            //Debug.Log("You pressed an inactive key");
        }


        rb2d.velocity = movement * speed / 2;
        //Debug.Log(rb2d.velocity);

        float up = Vector2.Dot(Vector2.up, rb2d.velocity);
        float down = Vector2.Dot(Vector2.down, rb2d.velocity);
        float left = Vector2.Dot(Vector2.left, rb2d.velocity);
        float right = Vector2.Dot(Vector2.right, rb2d.velocity);
        //Debug.Log(up + " " + down + " " + left + " " + right);

        int walk = -1;
        float max = 0;

        if (up > max)
        {
            max = up;
            walk = 0;
        }
        if (down > max)
        {
            max = down;
            walk = 1;
        }
        if (left > max)
        {
            max = left;
            walk = 2;
        }
        if (right > max)
        {
            max = right;
            walk = 3;
        }

        m_Animator.SetInteger("direction", walk);

        m_Animator.SetFloat("speed", Mathf.Abs(rb2d.velocity.y));
        m_Animator.SetFloat("speedx", Mathf.Abs(rb2d.velocity.x));

    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Guard")
        {
            onPlayerCaught?.Invoke(this, collision.gameObject);
            this.enabled = false;
            m_Animator.SetInteger("direction", -1);
            this.rb2d.velocity = Vector2.zero;
            PathPlanning.freezeThese.Add(rb2d);
//            Debug.LogError("END THE GAME IDIOT");
        }
        if (collision.gameObject.tag == "Collectible")
        {
            Debug.LogError("nom nom nom");
            collision.gameObject.SetActive(false);
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        onPlayerSpotted?.Invoke(this, collision.gameObject);
    }

}
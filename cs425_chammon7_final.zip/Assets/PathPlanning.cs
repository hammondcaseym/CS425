﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;


public class Node : IComparable<Node>
{
    public Vector2 pos;
    public float f, g;
    public List<Node> neighbors;
    public Node parent;
    public bool visited;
    public bool free;

    public Node()
    {
        pos = Vector2.zero;
        f = float.MaxValue;
        g = float.MaxValue;
        neighbors = new List<Node>();
        parent = null;
        visited = false;
        free = true;
    }
    public int CompareTo(Node n)
    {
        float res = this.f - n.f;
        if (res > 0)
        {
            return 1;
        }
        else if (res == 0)
        {
            return 0;
        }
        else
        {
            return -1;
        }
    }
}

public class PathPlanning : MonoBehaviour
{
    public static List<Rigidbody2D> freezeThese;
    public int m_width, m_height;
    List<List<Node>> m_grid;
    public Collider2D target;
    public float screenWidth = 13.527f;
    public float screenHeight = 7.6f;
    public float gridScale = 100f;

    private void LateUpdate()
    {
        if (Input.GetMouseButtonDown(0))
        {
            Vector2 position = Input.mousePosition;
            float pwidth = position.x / Screen.width;
            float pheight = position.y / Screen.height;
        }
    }

    private void Update()
    {
        foreach(Rigidbody2D rb in freezeThese)
        {
            rb.velocity = Vector3.zero;
        }
    }

    private void Start()
    {
        freezeThese = new List<Rigidbody2D>();
        Build();

        //foreach (List<Node> list in m_grid)
        //{
        //    foreach (Node node in list)
        //    {
        //        if (!node.free)
        //        {
        //            GameObject debug = Instantiate(debugObject, transform);
        //            debug.transform.position = node.pos / gridScale;
        //            debug.GetComponentInChildren<TextMeshPro>().text = "";// node.free + "";
        //        }
        //    }
        //}

//        DrawPath(new Vector2(5.94f, 5.88f), new Vector2(8.3f, 2.85f));
    }

    private void DrawPath(Vector2 a, Vector2 b)
    {
        List<Vector2> path;
        bool found = find_path(a, b, out path);
        Debug.Log(found);
        LineRenderer lr = GetComponent<LineRenderer>();
        lr.positionCount = path.Count;
        for (int i = 0; i < path.Count; i++)
        {
            lr.SetPosition(i, path[i]);
        }
    }

    public bool Build()
    {
        if (m_grid != null)
        {
            return false;
        }
        m_grid = new List<List<Node>>();
        for (int i = 0; i < m_height; i++)
        {
            List<Node> nodes = new List<Node>(m_width);
            for (int j = 0; j < m_width; j++)
            {
                nodes.Add(new Node());
            }
            m_grid.Add(nodes);
        }
        float cell_w = screenWidth * gridScale / m_width;
        float cell_h = screenHeight * gridScale / m_height;
        int icell_w = (int)cell_w;
        int icell_h = (int)cell_h;
        for (int i = 0; i < m_height; i++)
        {
            for (int j = 0; j < m_width; j++)
            {
                Node n = m_grid[i][j];
                n.pos = new Vector2(j * icell_w, i * icell_h);
                int count = 0;
                for (int k = i - 1; k <= i + 1; k++)
                {
                    if (k < 0 || k >= m_height)
                    {
                        continue;
                    }
                    for (int l = j - i; l <= j + 1; l++)
                    {
                        if (l < 0 || l >= m_width || (k == i && l == j))
                        {
                            continue;
                        }
                        n.neighbors.Add(m_grid[k][l]);
                        count++;
                    }
                }
                n.free = true;
                for (int a = 0; a < icell_w; a++)
                {
                    for (int b = 0; b < icell_h; b++)
                    {
                        if (collision_detection(new Vector2((a + (icell_w * j)) / gridScale, (b + (icell_h * i)) / gridScale)))
                        {
                            n.free = false;
                            break;
                        }
                    }
                }
            }
        }
        return true;
    }

    public bool find_path(Vector2 start, Vector2 goal, out List<Vector2> path)
    {
        start *= gridScale;
        goal *= gridScale;
        path = new List<Vector2>();
        float cell_w = screenWidth * gridScale / m_width;
        float cell_h = screenHeight * gridScale / m_height;
        int icell_w = (int)cell_w;
        int icell_h = (int)cell_h;
        for (int i = 0; i < m_height; i++)
        {
            for (int j = 0; j < m_width; j++)
            {
                Node n = m_grid[i][j];
                n.visited = false;
                n.f = 0;
                n.g = 0;
                n.parent = null;
            }
        }

        SortedDictionary<Node, Node> open = new SortedDictionary<Node, Node>();

        int sa = (int)start.y / icell_h;
        int sb = (int)start.x / icell_w;
        int ga = (int)goal.y / icell_h;
        int gb = (int)goal.x / icell_w;
        if (sa >= m_grid.Count)
            sa = m_grid.Count - 1;
        if (sb >= m_grid[0].Count)
            sb = m_grid[0].Count - 1;
        if (ga >= m_grid.Count)
            ga = m_grid.Count - 1;
        if (gb >= m_grid[0].Count)
            gb = m_grid[0].Count - 1;
        Node S = m_grid[sa][sb];
        Node G = m_grid[ga][gb];
        bool error = false;
        if (!S.free)
        {
            Debug.LogError("! Error: Start point makes the agent collide with something");
            error = true;
        }
        if (!G.free)
        {
            Debug.LogError("! Error: Goal point makes the agent collide with something");
            error = true;
        }
        if (error)
        {
            return false;
        }
        bool found = false;

        S.f = 0;
        S.g = 0;
        S.visited = true;


        open.Add(S, S);

        //A* Starts Here

        while (open.Count != 0)
        {

            //pop heap(open begin, open end, compare)
            //Node best option = open back
            //open pop_back
            Node best_option = open.First().Key;
            open.Remove(best_option);

            //if(best is the goal){
            //   trace_back(goal,path);
            //}

            if (best_option == G)
            {
                found = true;
                //traceback(goal,path)
                Node temp = best_option;
                while (temp != null)
                {
                    path.Add(temp.pos / gridScale);
                    temp = temp.parent;
                }
                return found;
            }

            //for(each node in best_option's neighbors)
            foreach (Node it in best_option.neighbors)
            {
                if (!it.visited)
                {
                    if (it.free)
                    {
                        it.g = best_option.g + cost(best_option.pos, it.pos);
                        it.f = it.g + cost(it.pos, G.pos);
                    }
                    else
                    {
                        it.g = float.PositiveInfinity;
                        it.f = float.PositiveInfinity;
                    }
                    it.visited = true;
                    if (!open.ContainsKey(it))
                    {
                        open.Add(it, it);
                    }
                    it.parent = best_option;
                }
                else
                {
                    if (best_option.parent != it)
                    {
                        float cost = it.g;
                        if (it.f < cost)
                        {
                            it.f = cost;
                            it.parent = best_option;
                        }
                    }
                }
            }
        }

        //A* Ends Here

        return found;
    }

    bool collision_detection(Vector2 pos)
    {
        GameObject player = GameObject.FindGameObjectWithTag("Player");
        Bounds bounds = player.GetComponent<Collider2D>().bounds;
        Vector2[] points =
                {
            pos+new Vector2(bounds.extents.x,bounds.extents.y),
            pos+new Vector2(-bounds.extents.x,-bounds.extents.y),
            pos+new Vector2(-bounds.extents.x,bounds.extents.y),
            pos+new Vector2(bounds.extents.x,-bounds.extents.y),
        };
        Collider2D[] colliders = GameObject.FindObjectsOfType<Collider2D>();
        foreach (Collider2D collider in colliders)
        {
            if (collider.gameObject.tag == "Light" || collider.gameObject.tag == "Player" || collider.gameObject.tag == "Guard")
            {
                continue;
            }
            foreach (Vector2 point in points)
            {
                if (collider.OverlapPoint(point))
                {
                    return true;
                }
            }
        }
        return false;
    }

    float cost(Vector2 pos1, Vector2 pos2)
    {
        return (pos1 - pos2).magnitude;
    }
}

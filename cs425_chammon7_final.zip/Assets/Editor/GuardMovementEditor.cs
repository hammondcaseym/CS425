﻿using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(GuardMovement))]
public class GuardMovementEditor : Editor
{

    public override void OnInspectorGUI()
    {
        DrawDefaultInspector();
        GuardMovement movement = target as GuardMovement;
        if (GUILayout.Button("Recenter"))
        {
            if (movement.pathing.Length > 0)
            {
                movement.transform.localPosition=movement.pathing[0];
            }
        }

    }

    private void OnSceneGUI()
    {
        GuardMovement movement = target as GuardMovement;
        Handles.color = movement.debugPathColor;
        for (int i = 0; i < movement.pathing.Length - 1; i++)
        {
            Handles.DrawLine(movement.pathing[i],movement.pathing[i + 1]);
        }

    }


}

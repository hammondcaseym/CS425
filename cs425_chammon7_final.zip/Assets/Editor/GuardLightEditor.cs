﻿using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(GuardLight))]
public class GuardLightEditor : Editor
{
    public override void OnInspectorGUI()
    {
        DrawDefaultInspector();
        GuardLight light = target as GuardLight;
        if (GUILayout.Button("Up"))
        {
            light.Apply(light.upPos);
        }
        if (GUILayout.Button("Down"))
        {
            light.Apply(light.downPos);
        }
        if (GUILayout.Button("Left"))
        {
            light.Apply(light.leftPos);
        }
        if (GUILayout.Button("Right"))
        {
            light.Apply(light.rightPos);
        }

    }
}
